package se.ju.student.bako21tu.todolist

data class Todo(
    val title: String,
    var isChecked: Boolean = false
)